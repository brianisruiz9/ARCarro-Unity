The Creative Commons Non-Commercial (CC-BY-NC) license restricts the use of this model in any and all commercial environments. 

In Short:

> You can't use In-App purchases in any game using this model (in whole or in part)
> You can't sell any game/app using this model (in whole or in part)
> You cannot monetize any app/game using this model through ads (in whole or in part)
> You cannot make any revenue using this model (in whole or in part)

If you wish to use this commercially, please contact the author and clarify.